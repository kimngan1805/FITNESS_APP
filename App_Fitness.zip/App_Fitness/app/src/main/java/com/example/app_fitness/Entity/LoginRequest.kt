package com.example.app_fitness.Entity

data class LoginRequest(
    val username: String,
    val password: String
)