package com.example.app_fitness.Activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.app_fitness.R

class ActivityEditProfile : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)
    }
}
