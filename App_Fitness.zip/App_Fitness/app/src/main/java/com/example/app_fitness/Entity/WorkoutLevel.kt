package com.example.app_fitness.Entity

data class WorkoutLevel(
    val id:Int,
    val level_name: String,
    val description: String,
    val image_url: String
)
