package com.example.app_fitness.Activity

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.NumberPicker
import androidx.appcompat.app.AppCompatActivity
import com.example.app_fitness.R
import com.example.app_fitness.databinding.ActivityCreateMeasurementBinding
import java.lang.reflect.InvocationTargetException

class CreateMeasurementActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCreateMeasurementBinding
    private var isWeightPickerVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreateMeasurementBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Thiết lập NumberPicker
        binding.weightPicker.minValue = 30
        binding.weightPicker.maxValue = 150
        binding.weightPicker.value = binding.weightEditText.text.toString().toIntOrNull() ?: 47

        // Thay đổi màu divider (có thể không hoạt động trên mọi thiết bị/phiên bản)
        try {
            val pickerFields = NumberPicker::class.java.declaredFields
            for (pf in pickerFields) {
                if (pf.name == "mSelectionDivider") {
                    pf.isAccessible = true
                    try {
                        pf.set(binding.weightPicker, resources.getDrawable(R.drawable.numberpicker_divider))
                    } catch (e: IllegalArgumentException) {
                        e.printStackTrace()
                    } catch (e: IllegalAccessException) {
                        e.printStackTrace()
                    }
                    break
                }
            }
        } catch (e: NoSuchFieldException) {
            e.printStackTrace()
        } catch (e: IllegalAccessException) {
            e.printStackTrace()
        }

        // Lắng nghe sự thay đổi giá trị trong NumberPicker
        binding.weightPicker.setOnValueChangedListener { _, _, newVal ->
            binding.weightEditText.setText(newVal.toString())
        }

        binding.closeButton.setOnClickListener {
            // Ẩn NumberPicker khi nhấn nút close
            binding.weightPicker.visibility = View.GONE
            isWeightPickerVisible = false
            finish() // Đóng Activity và quay lại
        }

        binding.saveButton.setOnClickListener {
            // Xử lý logic lưu dữ liệu đo lường
            val date = binding.dateTextView.text.toString()
            val result = binding.resultEditText.text.toString()
            val weight = binding.weightEditText.text.toString()
            val height = binding.heightEditText.text.toString()
            // ... (lấy các giá trị khác) ...
            // Thực hiện lưu dữ liệu
            finish()
        }

        binding.dateLayout.setOnClickListener {
            // Xử lý logic chọn ngày
        }

        // Lắng nghe sự kiện click trên dòng "Weight, kg"
        binding.weightContainer.setOnClickListener {
            isWeightPickerVisible = !isWeightPickerVisible
            binding.weightPicker.visibility = if (isWeightPickerVisible) View.VISIBLE else View.GONE
            // Ẩn bàn phím nếu đang hiển thị (nếu cần)
        }
    }
}