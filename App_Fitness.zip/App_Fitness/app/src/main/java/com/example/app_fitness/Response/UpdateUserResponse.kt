package com.example.app_fitness.Response

data class UpdateUserResponse (
    val success: Boolean,
    val message: String

)
